from django.apps import AppConfig


class BuddyAppConfig(AppConfig):
    name = 'buddy_app'
